# TamilTrust AI — responsive website + secure AI backend

This package includes the TamilTrust AI web interface and a Node.js backend. The website is designed to be served over HTTPS and opened on phones, tablets, and desktop browsers. AI requests are sent to `/api/ai`; the secret key is stored only in the hosting provider's environment settings, never in the HTML.

## Files
- `public/index.html` — website interface (TamilTrust AI, including AI Padivu and AI Karuvigal UI).
- `server.js` — static web server and Gemini API proxy.
- `package.json` — start command.
- `.env.example` — example variable names only; contains no secret.

## Before you start: API key safety
If you have already pasted an API key into a chat or public place, revoke it and create a new one. Never commit a real key to GitHub or place it in `public/index.html`. The backend in this package expects a Google Gemini API key. If your key came from a different provider, it will not work with this Gemini backend.

Create a Gemini key in Google AI Studio: https://aistudio.google.com/app/apikey

## Run locally (Node.js 18+)
1. Install Node.js 18 or newer: https://nodejs.org/
2. Open a terminal in this folder.
3. Set `GEMINI_API_KEY` in your terminal environment (do not put the real key in a source file).
4. Run `npm start`.
5. Open `http://localhost:3000`.

PowerShell:
```powershell
$env:GEMINI_API_KEY="PASTE_YOUR_NEW_GEMINI_KEY_HERE"
npm start
```

macOS/Linux:
```sh
export GEMINI_API_KEY="PASTE_YOUR_NEW_GEMINI_KEY_HERE"
npm start
```

## Publish with Render + GitHub
1. Create a **private** repository at https://github.com/ and upload the contents of this folder to its root (including `server.js`, `package.json`, `.env.example`, `README.md`, and `public/`).
2. At https://dashboard.render.com/ choose **New → Web Service**, connect the repository, and select it.
3. Set **Runtime** to Node, **Build command** to `npm install`, and **Start command** to `npm start`.
4. In Render's **Environment** settings, add `GEMINI_API_KEY` as the key and your newly generated Gemini key as the value. Optionally add `GEMINI_MODEL` = `gemini-2.5-flash`. Do not add the key to GitHub.
5. Deploy. Open the HTTPS URL provided by Render on your phone and computer.
6. Check `https://YOUR-SERVICE-URL/api/health`. It should show `"ok":true` and `"configured":true`. Do not post the URL with any secret values.
7. Test AI Padivu (image/text reading) and every AI Karuvigal tool. A successful deploy does not by itself guarantee every AI action has been tested. Check Render logs and Google AI Studio quota if a tool fails.

## Cross-device checks
- Open the public HTTPS URL on Android/iPhone and on a desktop browser.
- Try portrait and landscape orientation, keyboard input, image upload, and each AI tool.
- If AI works on one device but not another, check browser console/network errors, file type/size, and internet connection.

## Notes
- The browser needs internet access to call the hosted backend and Gemini.
- Gemini usage may be subject to quotas, billing, and provider terms.
- This package cannot publish itself: a hosting account and API key must be configured by you.
