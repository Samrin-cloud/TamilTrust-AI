const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const ROOT = path.join(__dirname, 'public');
const MAX_BODY = 18 * 1024 * 1024;

function send(res, status, data, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type': type, 'Cache-Control':'no-store',
    'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'strict-origin-when-cross-origin'});
  res.end(type.startsWith('application/json') ? JSON.stringify(data) : data);
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let data='', size=0;
    req.on('data', chunk=>{ size += chunk.length; if(size>MAX_BODY){reject(new Error('Request too large')); req.destroy();} else data+=chunk; });
    req.on('end',()=>{try{resolve(JSON.parse(data||'{}'));}catch{reject(new Error('Invalid JSON'));}});
    req.on('error',reject);
  });
}
const server = http.createServer(async (req,res)=>{
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/health' && req.method === 'GET') {
    return send(res,200,{ok:true,configured:Boolean(API_KEY),model:MODEL});
  }
  if (url.pathname === '/api/ai' && req.method === 'POST') {
    if (!API_KEY) return send(res,503,{code:'not_configured',error:'AI is not configured yet. Add GEMINI_API_KEY in the hosting environment.'});
    try {
      const body=await readBody(req);
      if(typeof body.prompt!=='string' || !body.prompt.trim()) return send(res,400,{code:'bad_request',error:'Prompt is required.'});
      const parts=[{text:body.prompt}];
      for(const im of (Array.isArray(body.images)?body.images.slice(0,4):[])) {
        if(!im || typeof im.data!=='string' || !/^image\/(jpeg|png|webp|gif)$/.test(im.mimeType||'')) continue;
        parts.push({inline_data:{mime_type:im.mimeType,data:im.data}});
      }
      const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,{
        method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':API_KEY},
        body:JSON.stringify({contents:[{role:'user',parts}],generationConfig:{temperature:0.3,maxOutputTokens:4000}})
      });
      const result=await response.json().catch(()=>({}));
      if(!response.ok) {
        const status=response.status===429?429:(response.status===401||response.status===403?502:502);
        return send(res,status,{code:response.status===429?'rate_limited':'api_error',error:(result.error?.message||`AI provider returned ${response.status}`).slice(0,400)});
      }
      const text=(result.candidates||[]).flatMap(c=>c.content?.parts||[]).map(p=>p.text||'').join('');
      if(!text) return send(res,502,{code:'empty',error:'The AI provider returned no text. Try again.'});
      return send(res,200,{text});
    } catch(e) {
      return send(res,400,{code:'bad_request',error:e.message||'Could not process request.'});
    }
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res,405,{error:'Method not allowed'});
  let pathname=decodeURIComponent(url.pathname);
  if(pathname==='/') pathname='/index.html';
  const file=path.normalize(path.join(ROOT,pathname));
  if(!file.startsWith(ROOT)) return send(res,403,{error:'Forbidden'});
  fs.readFile(file,(err,data)=>{
    if(err) return send(res,404,{error:'Not found'});
    const ext=path.extname(file);
    const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8'};
    send(res,200,data,types[ext]||'application/octet-stream');
  });
});
server.listen(PORT,'0.0.0.0',()=>console.log(`TamilTrust AI running on port ${PORT}; AI configured: ${Boolean(API_KEY)}`));
